# Jarvis Overlay (Android)

A floating Jarvis assistant that sits over other apps. Works offline.
`app/src/main/assets/jarvis.html` is the same single file that also runs in a normal browser.

## What it can do on Android
- **Open ANY installed app by name**: "open WhatsApp", "launch Google Pay", "open Instagram" (also "insta", "yt"). Names are matched loosely against every app on your phone.
- **Phone actions**: "call mom" (opens the dialer with the number), "call 9876543210", "text 9876543210 hello", "whatsapp 9876543210 hi", "navigate to Kochi", "play <song>", "search for ...", "set alarm for 6:30 am".
- **System control** (needs the accessibility switch): "go home", "go back", "recent apps", "open notifications", "quick settings", "scroll down", "take a screenshot", "lock the phone", "power menu".
- **Phone controls**: "torch on/off", "volume up/down/40", "mute the phone". For Wi-Fi, Bluetooth, airplane mode, mobile data, location, brightness and hotspot, Android does not let apps toggle them, so Jarvis opens the right panel.
- **Offline voice input** (Vosk) and spoken replies (Android text-to-speech).
- **On-device AI** (MediaPipe + a `.task` model) for anything else.
- Built-in: time/date, calculator, timers, notes, tasks, unit conversion, jokes, battery, themes.

## Build the APK
1. Install Android Studio and open this `jarvis-android` folder.
2. Let Gradle sync. **The first build needs internet** (SDK pieces, libraries, and the ~40 MB English speech model saved to `app/src/main/assets/vosk-model`). After that Jarvis runs offline.
3. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s), then install the APK.

## First run on the phone
1. Open **Jarvis**, tap **Start Jarvis overlay**. Allow *Display over other apps*, return, tap Start again. Allow microphone, contacts and notifications.
2. Tap **Enable system control** and switch on "Jarvis system control". On Android 13+ the switch may be greyed out for apps installed outside the Play Store: open Settings > Apps > Jarvis > (⋮) > **Allow restricted settings**, then try again.
3. (Optional) For open questions, download a MediaPipe LLM `.task` model (for example Gemma 3 1B int4 from the `litert-community` page on Hugging Face; accept its license), copy it to the phone, tap **Import AI model**, and restart the overlay.

## Limits worth knowing
- Android lets an app open another app only while it has a visible window. Jarvis's overlay counts, but a few phones (some Xiaomi/Oppo/Vivo/Samsung settings) block it; Jarvis then says so. Allow "Display pop-up windows while running in background" or set battery to Unrestricted.
- Jarvis starts calls and messages for you (dialer and composer open ready); you tap the final button. This is deliberate, so it can never place a call or send a message by mistake.
- The accessibility service only performs the system actions above and never reads your screen.
- The AI model needs a recent phone (about 4 GB free RAM); the first answer is slow while it loads.
- If the `tasks-genai` version in `app/build.gradle.kts` is rejected, use the newest `com.google.mediapipe:tasks-genai` on Maven Central.
