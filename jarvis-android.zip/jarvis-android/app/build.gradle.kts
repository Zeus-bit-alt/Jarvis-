import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.jarvis"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.jarvis"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        jniLibs.useLegacyPackaging = true
    }
}

dependencies {
    // Offline speech recognition
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
    // On-device language model
    implementation("com.google.mediapipe:tasks-genai:0.10.24")
}

// Downloads the small English offline speech model once, on the first build.
val voskModelDir = file("src/main/assets/vosk-model")
tasks.register("downloadVoskModel") {
    onlyIf { !voskModelDir.exists() }
    doLast {
        val zip = File(layout.buildDirectory.get().asFile, "vosk-model.zip")
        zip.parentFile.mkdirs()
        println("Downloading offline speech model (about 40 MB)...")
        URL("https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip")
            .openStream().use { input -> zip.outputStream().use { input.copyTo(it) } }
        val assetsDir = file("src/main/assets")
        project.copy {
            from(zipTree(zip))
            into(assetsDir)
        }
        file("src/main/assets/vosk-model-small-en-us-0.15").renameTo(voskModelDir)
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("downloadVoskModel") }
