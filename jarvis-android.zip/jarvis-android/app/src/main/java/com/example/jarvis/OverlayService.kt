package com.example.jarvis

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.example.jarvis.STOP"
        private const val CHANNEL = "jarvis_overlay"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var panel: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var web: WebView? = null
    private var panelOpen = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // offline speech recognition
    private var voskModel: Model? = null
    private var speech: SpeechService? = null

    // on-device language model
    @Volatile private var llm: LlmInference? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun js(code: String) = main.post { web?.evaluateJavascript(code, null) }
    private fun q(text: String) = JSONObject.quote(text)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        startAsForeground()
        createPanel()
        createBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            ttsReady = true
        }
    }

    // ---------- foreground notification ----------
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jarvis overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is active")
            .setContentText("Tap the floating J to talk. Tap Stop to remove it.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .setOngoing(true)
            .build()
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        when {
            Build.SDK_INT >= 34 -> {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                if (mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                startForeground(1, n, type)
            }
            Build.SDK_INT >= 30 && mic ->
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else -> startForeground(1, n)
        }
    }

    // ---------- floating bubble ----------
    private fun createBubble() {
        val b = TextView(this).apply {
            text = "J"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#19D3FF"))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E6020A12"))
                setStroke(dp(3), Color.parseColor("#19D3FF"))
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0
            var touchX = 0f; var touchY = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.x = startX + dx
                            lp.y = startY + dy
                            wm.updateViewLayout(b, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) setPanelOpen(!panelOpen)
                }
                return true
            }
        })
        wm.addView(b, lp)
        bubble = b
    }

    // ---------- expandable panel (kept alive so timers keep running) ----------
    private val hiddenFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val shownFlags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    private fun createPanel() {
        val root = object : FrameLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    setPanelOpen(false)
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        root.setBackgroundColor(Color.parseColor("#02080F"))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#06243A"))
            setPadding(dp(14), 0, dp(6), 0)
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 14f
            letterSpacing = 0.25f
            setTextColor(Color.parseColor("#19D3FF"))
        }
        val minimize = TextView(this).apply {
            text = "—"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#19D3FF"))
            setOnClickListener { setPanelOpen(false) }
        }
        val close = TextView(this).apply {
            text = "✕"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#19D3FF"))
            setOnClickListener { stopSelf() }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        bar.addView(minimize, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))

        val wv = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setBackgroundColor(Color.parseColor("#02080F"))
            addJavascriptInterface(Bridge(), "JarvisNative")
            loadUrl("file:///android_asset/jarvis.html")
        }
        web = wv

        col.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)))
        col.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            hiddenFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(48)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        root.alpha = 0f
        wm.addView(root, lp)
        panel = root
        panelLp = lp
    }

    private fun setPanelOpen(open: Boolean) {
        val p = panel ?: return
        val lp = panelLp ?: return
        panelOpen = open
        val dm = resources.displayMetrics
        if (open) {
            lp.width = (dm.widthPixels * 0.94).toInt()
            lp.height = (dm.heightPixels * 0.62).toInt()
            lp.flags = shownFlags
            p.alpha = 1f
            bubble?.visibility = View.GONE
        } else {
            lp.width = 1
            lp.height = 1
            lp.flags = hiddenFlags
            p.alpha = 0f
            bubble?.visibility = View.VISIBLE
        }
        wm.updateViewLayout(p, lp)
    }

    // ---------- offline speech recognition (Vosk) ----------
    private fun copyAssets(path: String, dest: File) {
        val children = assets.list(path) ?: return
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (c in children) copyAssets("$path/$c", File(dest, c))
        }
    }

    private fun loadVoskModel(): Model? {
        voskModel?.let { return it }
        val dir = File(filesDir, "vosk-model")
        val ready = File(dir, ".ready")
        if (!ready.exists()) {
            dir.deleteRecursively()
            copyAssets("vosk-model", dir)
            ready.writeText("ok")
        }
        return Model(dir.absolutePath).also { voskModel = it }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            js("onNativeError(${q("Microphone permission is missing. Open the Jarvis app and allow the microphone.")})")
            return
        }
        thread {
            try {
                js("onNativeError(${q("Loading voice model...")})")
                val model = loadVoskModel() ?: throw IllegalStateException("model missing")
                main.post {
                    try {
                        speech?.stop()
                        val svc = SpeechService(Recognizer(model, 16000f), 16000f)
                        speech = svc
                        js("onNativeListening(true)")
                        svc.startListening(object : RecognitionListener {
                            override fun onPartialResult(h: String?) {}
                            override fun onResult(h: String?) {
                                val text = try { JSONObject(h ?: "{}").optString("text") } catch (e: Exception) { "" }
                                if (text.isNotBlank()) {
                                    svc.stop()
                                    js("onNativeListening(false)")
                                    js("onNativeVoice(${q(text)})")
                                }
                            }
                            override fun onFinalResult(h: String?) {}
                            override fun onError(e: Exception?) {
                                js("onNativeListening(false)")
                                js("onNativeError(${q("Voice error: ${e?.message}")})")
                            }
                            override fun onTimeout() {
                                js("onNativeListening(false)")
                                js("onNativeError(${q("I didn't hear anything.")})")
                            }
                        }, 10000)
                    } catch (e: Exception) {
                        js("onNativeError(${q("Could not start listening: ${e.message}")})")
                    }
                }
            } catch (e: Exception) {
                js("onNativeError(${q("Voice model is not installed in this build: ${e.message}")})")
            }
        }
    }

    // ---------- on-device language model (MediaPipe) ----------
    private fun answer(question: String) {
        thread {
            try {
                val file = File(filesDir, "model.task")
                if (!file.exists()) {
                    js("onNativeAnswer(${q("No AI model is installed. Import one in the Jarvis app.")})")
                    return@thread
                }
                val engine = llm ?: synchronized(this) {
                    llm ?: LlmInference.createFromOptions(
                        this,
                        LlmInference.LlmInferenceOptions.builder()
                            .setModelPath(file.absolutePath)
                            .setMaxTokens(768)
                            .build()
                    ).also { llm = it }
                }
                val prompt = "<start_of_turn>user\nYou are JARVIS, a concise, polite, witty assistant. " +
                        "Answer in at most three short sentences.\n\n$question<end_of_turn>\n<start_of_turn>model\n"
                val reply = engine.generateResponse(prompt).trim()
                js("onNativeAnswer(${q(reply.ifBlank { "I have no answer for that." })})")
            } catch (e: Throwable) {
                js("onNativeAnswer(${q("The AI model failed: ${e.message}")})")
            }
        }
    }

    // ---------- helpers for launching things ----------
    private val appAliases = mapOf(
        "insta" to "instagram", "ig" to "instagram", "yt" to "youtube", "fb" to "facebook",
        "wa" to "whatsapp", "gpay" to "googlepay", "playstore" to "playstore"
    )

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun lev(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return dp[a.length][b.length]
    }

    /** Starts an activity from the service and tucks the panel away. */
    private fun go(i: Intent): Boolean = try {
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        main.post { setPanelOpen(false) }
        true
    } catch (e: Exception) {
        false
    }

    // ---------- bridge exposed to the web page ----------
    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String) {
            if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }

        @JavascriptInterface
        fun stop() {
            tts?.stop()
        }

        @JavascriptInterface
        fun listen() = startListening()

        @JavascriptInterface
        fun hasModel(): Boolean = File(filesDir, "model.task").exists()

        @JavascriptInterface
        fun ask(question: String) = answer(question)

        @JavascriptInterface
        fun openApp(name: String): String {
            val pm = packageManager
            val apps = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            )
            var wanted = norm(name)
            wanted = appAliases[wanted] ?: wanted
            if (wanted.isEmpty()) return "Which app, sir?"
            var best: android.content.pm.ResolveInfo? = null
            var bestScore = 0
            for (a in apps) {
                val label = norm(a.loadLabel(pm).toString())
                val score = when {
                    label == wanted -> 100
                    label.startsWith(wanted) -> 80
                    label.contains(wanted) -> 60
                    wanted.length >= 4 && wanted.contains(label) && label.length >= 3 -> 50
                    wanted.length >= 4 && lev(label, wanted) <= 2 -> 45 - lev(label, wanted)
                    else -> 0
                }
                if (score > bestScore) { bestScore = score; best = a }
            }
            val match = best ?: return "I can't find an app called $name on this phone."
            val label = match.loadLabel(pm)
            val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
                ?: return "I can't open $label."
            return if (go(launch)) "Opening $label." else "Android blocked me from opening $label."
        }

        @JavascriptInterface
        fun dial(number: String): String = try {
            startActivity(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            main.post { setPanelOpen(false) }
            "Dialer opened for $number."
        } catch (e: Exception) {
            "I couldn't open the dialer."
        }

        @JavascriptInterface
        fun setAlarm(hour: Int, minute: Int): String = try {
            startActivity(
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Alarm set for %d:%02d.".format(hour, minute)
        } catch (e: Exception) {
            "I couldn't set an alarm on this phone."
        }

        // ---------- system control via the accessibility service ----------
        @JavascriptInterface
        fun system(action: String): String {
            val svc = JarvisAccessibilityService.instance
                ?: return "I need the system-control permission. Open the Jarvis app and tap Enable system control."
            val global = when (action) {
                "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                "quicksettings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                "power" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
                "lock", "screenshot" -> {
                    if (Build.VERSION.SDK_INT < 28) return "That needs Android 9 or newer."
                    if (action == "lock") AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
                    else AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
                }
                "scrolldown", "scrollup" -> -1
                else -> return "Unknown system action."
            }
            // Hide the panel first so the action reaches the app underneath.
            main.post { setPanelOpen(false) }
            main.postDelayed({
                if (global == -1) svc.scroll(action == "scrolldown") else svc.performGlobalAction(global)
            }, 400)
            return when (action) {
                "home" -> "Going home."
                "back" -> "Going back."
                "recents" -> "Showing recent apps."
                "notifications" -> "Opening notifications."
                "quicksettings" -> "Opening quick settings."
                "power" -> "Opening the power menu."
                "lock" -> "Locking the screen."
                "screenshot" -> "Taking a screenshot."
                else -> "Scrolling."
            }
        }

        // ---------- direct phone controls ----------
        @JavascriptInterface
        fun torch(on: Boolean): String = try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "This phone has no flashlight."
            cm.setTorchMode(id, on)
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "I couldn't control the flashlight."
        }

        @JavascriptInterface
        fun volume(cmd: String): String {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val ui = AudioManager.FLAG_SHOW_UI
            val s = AudioManager.STREAM_MUSIC
            return when {
                cmd == "up" -> { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, ui); "Volume up." }
                cmd == "down" -> { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, ui); "Volume down." }
                cmd == "mute" -> { am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, ui); "Muted." }
                cmd == "unmute" -> { am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, ui); "Unmuted." }
                cmd == "show" -> { am.adjustStreamVolume(s, AudioManager.ADJUST_SAME, ui); "Here is the volume." }
                cmd.toIntOrNull() != null -> {
                    val pct = cmd.toInt().coerceIn(0, 100)
                    am.setStreamVolume(s, am.getStreamMaxVolume(s) * pct / 100, ui)
                    "Volume at $pct percent."
                }
                else -> "I didn't understand that volume command."
            }
        }

        @JavascriptInterface
        fun settings(which: String): String {
            val q = Build.VERSION.SDK_INT >= 29
            val action = when (which) {
                "wifi" -> if (q) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
                "internet", "mobiledata" -> if (q) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_DATA_ROAMING_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "airplanemode", "flightmode" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                "location", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                "brightness", "displaysettings" -> Settings.ACTION_DISPLAY_SETTINGS
                "hotspot" -> Settings.ACTION_WIRELESS_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            return if (go(Intent(action)))
                "Android doesn't let apps flip $which directly, so I opened its controls."
            else "I couldn't open those settings."
        }

        @JavascriptInterface
        fun navigate(place: String): String {
            val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
            if (go(nav)) return "Starting navigation to $place."
            return if (go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place)))))
                "Showing $place on the map." else "I couldn't open a maps app."
        }

        @JavascriptInterface
        fun play(query: String): String {
            val media = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(SearchManager.QUERY, query)
            if (go(media)) return "Playing $query."
            val yt = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))
            return if (go(yt)) "Searching YouTube for $query." else "I couldn't find a player."
        }

        @JavascriptInterface
        fun webSearch(query: String): String {
            val s = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query)
            if (go(s)) return "Searching for $query."
            return if (go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))))
                "Searching for $query." else "I couldn't open a browser."
        }

        @JavascriptInterface
        fun sms(number: String, body: String): String {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
                .putExtra("sms_body", body)
            return if (go(i)) "Message ready for $number. Tap send." else "I couldn't open the messages app."
        }

        @JavascriptInterface
        fun whatsapp(number: String, body: String): String {
            var digits = number.filter { it.isDigit() }
            if (digits.length == 10) digits = "91$digits" // assumes India when no country code is given
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(body)))
            return if (go(i)) "WhatsApp chat ready. Tap send." else "I couldn't open WhatsApp."
        }

        @JavascriptInterface
        fun callContact(name: String): String {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                return "I need the contacts permission. Open the Jarvis app and allow it."
            val cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val who = it.getString(0)
                    val number = it.getString(1)
                    return if (go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))))
                        "Calling $who. Tap the call button." else "I couldn't open the dialer."
                }
            }
            return "I couldn't find $name in your contacts."
        }
    }

    override fun onDestroy() {
        bubble?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        runCatching { speech?.shutdown() }
        runCatching { voskModel?.close() }
        runCatching { llm?.close() }
        web?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
