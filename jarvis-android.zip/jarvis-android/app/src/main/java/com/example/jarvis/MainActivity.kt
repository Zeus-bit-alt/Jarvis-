package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var info: TextView
    private val pickModel = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#02080F"))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 28f
            letterSpacing = 0.3f
            setTextColor(Color.parseColor("#19D3FF"))
            gravity = Gravity.CENTER
        }
        info = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#BFEFFF"))
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        val start = Button(this).apply {
            text = "Start Jarvis overlay"
            setOnClickListener { startOverlay() }
        }
        val stop = Button(this).apply {
            text = "Stop overlay"
            setOnClickListener {
                startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            }
        }
        val model = Button(this).apply {
            text = "Import AI model (.task file)"
            setOnClickListener {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }, pickModel
                )
            }
        }
        val access = Button(this).apply {
            text = "Enable system control (Home, Back, screenshot...)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(
                    this@MainActivity,
                    "Find \"Jarvis system control\" and turn it on. If it is greyed out: App info > ⋮ > Allow restricted settings.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(start)
        root.addView(access)
        root.addView(model)
        root.addView(stop)
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#02080F"))
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus(extra: String = "") {
        val overlay = Settings.canDrawOverlays(this)
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val ai = File(filesDir, "model.task").exists()
        val acc = JarvisAccessibilityService.instance != null
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        info.text = """
            ${if (overlay) "✔" else "✘"} Display over other apps
            ${if (mic) "✔" else "✘"} Microphone (offline voice)
            ${if (ai) "✔" else "✘"} On-device AI model
            ${if (acc) "✔" else "✘"} System control (accessibility)
            ${if (contacts) "✔" else "✘"} Contacts (call by name)
            $extra
        """.trimIndent()
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow \"Display over other apps\" for Jarvis, then come back", Toast.LENGTH_LONG).show()
            return
        }
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.RECORD_AUDIO
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.READ_CONTACTS
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) needed += Manifest.permission.POST_NOTIFICATIONS
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 1)
            return
        }
        launchService()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
        // Start even if the microphone was refused; Jarvis then works without voice input.
        launchService()
    }

    private fun launchService() {
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickModel || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        refreshStatus("Importing model, please wait (large files take a minute)...")
        thread {
            val result = try {
                val tmp = File(filesDir, "model.task.tmp")
                contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
                val dest = File(filesDir, "model.task")
                dest.delete()
                tmp.renameTo(dest)
                "Model imported. Restart the overlay to use it."
            } catch (e: Exception) {
                "Import failed: ${e.message}"
            }
            runOnUiThread { refreshStatus(result) }
        }
    }
}
