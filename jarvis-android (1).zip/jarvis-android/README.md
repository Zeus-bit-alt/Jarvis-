# Jarvis Overlay (Android)

A floating Jarvis assistant that sits over other apps. Works offline.

## Features
- Floating **J** bubble over every app; tap to open the panel, drag to move.
- **Offline voice input** (Vosk): tap the mic and speak. Replies are spoken by Android text-to-speech.
- **Open apps by voice/text**: "open WhatsApp", "launch YouTube", "call 9876543210" (opens the dialer), "set alarm for 6:30 am".
- **On-device AI** (MediaPipe + a Gemma-style `.task` model): anything Jarvis has no built-in skill for goes to the local model.
- Built-in skills: time/date, calculator, timers, notes, tasks, unit conversion, jokes, battery, themes.

## Build the APK
1. Install Android Studio and open this `jarvis-android` folder.
2. Let Gradle sync. **The first build needs internet**: it downloads the Android SDK pieces, the libraries, and the ~40 MB English speech model (saved into `app/src/main/assets/vosk-model`). After that, everything runs offline.
3. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s), then install the APK.

## First run on the phone
1. Open **Jarvis**. Tap **Start Jarvis overlay**.
2. Allow **Display over other apps**, return, tap Start again. Allow the microphone and notifications.
3. (Optional, for open questions) Download a MediaPipe LLM `.task` model, for example a Gemma 3 1B int4 `.task` file from the `litert-community` page on Hugging Face (you must accept the model's license there). Copy it to your phone, then tap **Import AI model** in the Jarvis app and pick the file. Restart the overlay.

## Notes
- The interface is `app/src/main/assets/jarvis.html`. Edit it to change skills or look.
- AI model needs a fairly recent phone (about 4 GB+ free RAM). The first question after starting is slow while the model loads.
- If the `tasks-genai` version in `app/build.gradle.kts` is rejected, pick the newest `com.google.mediapipe:tasks-genai` version on Maven Central.
- Some phones (Xiaomi, Oppo, Vivo, Samsung battery saver) kill background apps. Set Jarvis to "Unrestricted" battery usage.
- The overlay works only with the Android app; on a PC, `jarvis.html` runs without voice input or app launching.
