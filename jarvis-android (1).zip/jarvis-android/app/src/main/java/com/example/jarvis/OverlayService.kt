package com.example.jarvis

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.example.jarvis.STOP"
        private const val CHANNEL = "jarvis_overlay"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var panel: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var web: WebView? = null
    private var panelOpen = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // offline speech recognition
    private var voskModel: Model? = null
    private var speech: SpeechService? = null

    // on-device language model
    @Volatile private var llm: LlmInference? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun js(code: String) = main.post { web?.evaluateJavascript(code, null) }
    private fun q(text: String) = JSONObject.quote(text)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        startAsForeground()
        createPanel()
        createBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            ttsReady = true
        }
    }

    // ---------- foreground notification ----------
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jarvis overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is active")
            .setContentText("Tap the floating J to talk. Tap Stop to remove it.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .setOngoing(true)
            .build()
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        when {
            Build.SDK_INT >= 34 -> {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                if (mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                startForeground(1, n, type)
            }
            Build.SDK_INT >= 30 && mic ->
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else -> startForeground(1, n)
        }
    }

    // ---------- floating bubble ----------
    private fun createBubble() {
        val b = TextView(this).apply {
            text = "J"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#19D3FF"))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E6020A12"))
                setStroke(dp(3), Color.parseColor("#19D3FF"))
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0
            var touchX = 0f; var touchY = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.x = startX + dx
                            lp.y = startY + dy
                            wm.updateViewLayout(b, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) setPanelOpen(!panelOpen)
                }
                return true
            }
        })
        wm.addView(b, lp)
        bubble = b
    }

    // ---------- expandable panel (kept alive so timers keep running) ----------
    private val hiddenFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val shownFlags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    private fun createPanel() {
        val root = object : FrameLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    setPanelOpen(false)
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        root.setBackgroundColor(Color.parseColor("#02080F"))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#06243A"))
            setPadding(dp(14), 0, dp(6), 0)
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 14f
            letterSpacing = 0.25f
            setTextColor(Color.parseColor("#19D3FF"))
        }
        val minimize = TextView(this).apply {
            text = "—"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#19D3FF"))
            setOnClickListener { setPanelOpen(false) }
        }
        val close = TextView(this).apply {
            text = "✕"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#19D3FF"))
            setOnClickListener { stopSelf() }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        bar.addView(minimize, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))

        val wv = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setBackgroundColor(Color.parseColor("#02080F"))
            addJavascriptInterface(Bridge(), "JarvisNative")
            loadUrl("file:///android_asset/jarvis.html")
        }
        web = wv

        col.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)))
        col.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            hiddenFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(48)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        root.alpha = 0f
        wm.addView(root, lp)
        panel = root
        panelLp = lp
    }

    private fun setPanelOpen(open: Boolean) {
        val p = panel ?: return
        val lp = panelLp ?: return
        panelOpen = open
        val dm = resources.displayMetrics
        if (open) {
            lp.width = (dm.widthPixels * 0.94).toInt()
            lp.height = (dm.heightPixels * 0.62).toInt()
            lp.flags = shownFlags
            p.alpha = 1f
            bubble?.visibility = View.GONE
        } else {
            lp.width = 1
            lp.height = 1
            lp.flags = hiddenFlags
            p.alpha = 0f
            bubble?.visibility = View.VISIBLE
        }
        wm.updateViewLayout(p, lp)
    }

    // ---------- offline speech recognition (Vosk) ----------
    private fun copyAssets(path: String, dest: File) {
        val children = assets.list(path) ?: return
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (c in children) copyAssets("$path/$c", File(dest, c))
        }
    }

    private fun loadVoskModel(): Model? {
        voskModel?.let { return it }
        val dir = File(filesDir, "vosk-model")
        val ready = File(dir, ".ready")
        if (!ready.exists()) {
            dir.deleteRecursively()
            copyAssets("vosk-model", dir)
            ready.writeText("ok")
        }
        return Model(dir.absolutePath).also { voskModel = it }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            js("onNativeError(${q("Microphone permission is missing. Open the Jarvis app and allow the microphone.")})")
            return
        }
        thread {
            try {
                js("onNativeError(${q("Loading voice model...")})")
                val model = loadVoskModel() ?: throw IllegalStateException("model missing")
                main.post {
                    try {
                        speech?.stop()
                        val svc = SpeechService(Recognizer(model, 16000f), 16000f)
                        speech = svc
                        js("onNativeListening(true)")
                        svc.startListening(object : RecognitionListener {
                            override fun onPartialResult(h: String?) {}
                            override fun onResult(h: String?) {
                                val text = try { JSONObject(h ?: "{}").optString("text") } catch (e: Exception) { "" }
                                if (text.isNotBlank()) {
                                    svc.stop()
                                    js("onNativeListening(false)")
                                    js("onNativeVoice(${q(text)})")
                                }
                            }
                            override fun onFinalResult(h: String?) {}
                            override fun onError(e: Exception?) {
                                js("onNativeListening(false)")
                                js("onNativeError(${q("Voice error: ${e?.message}")})")
                            }
                            override fun onTimeout() {
                                js("onNativeListening(false)")
                                js("onNativeError(${q("I didn't hear anything.")})")
                            }
                        }, 10000)
                    } catch (e: Exception) {
                        js("onNativeError(${q("Could not start listening: ${e.message}")})")
                    }
                }
            } catch (e: Exception) {
                js("onNativeError(${q("Voice model is not installed in this build: ${e.message}")})")
            }
        }
    }

    // ---------- on-device language model (MediaPipe) ----------
    private fun answer(question: String) {
        thread {
            try {
                val file = File(filesDir, "model.task")
                if (!file.exists()) {
                    js("onNativeAnswer(${q("No AI model is installed. Import one in the Jarvis app.")})")
                    return@thread
                }
                val engine = llm ?: synchronized(this) {
                    llm ?: LlmInference.createFromOptions(
                        this,
                        LlmInference.LlmInferenceOptions.builder()
                            .setModelPath(file.absolutePath)
                            .setMaxTokens(768)
                            .build()
                    ).also { llm = it }
                }
                val prompt = "<start_of_turn>user\nYou are JARVIS, a concise, polite, witty assistant. " +
                        "Answer in at most three short sentences.\n\n$question<end_of_turn>\n<start_of_turn>model\n"
                val reply = engine.generateResponse(prompt).trim()
                js("onNativeAnswer(${q(reply.ifBlank { "I have no answer for that." })})")
            } catch (e: Throwable) {
                js("onNativeAnswer(${q("The AI model failed: ${e.message}")})")
            }
        }
    }

    // ---------- bridge exposed to the web page ----------
    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String) {
            if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }

        @JavascriptInterface
        fun stop() {
            tts?.stop()
        }

        @JavascriptInterface
        fun listen() = startListening()

        @JavascriptInterface
        fun hasModel(): Boolean = File(filesDir, "model.task").exists()

        @JavascriptInterface
        fun ask(question: String) = answer(question)

        @JavascriptInterface
        fun openApp(name: String): String {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(intent, 0)
            val wanted = name.lowercase().trim()
            val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
                ?: return "I can't find an app called $name."
            val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
                ?: return "I can't open ${match.loadLabel(pm)}."
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try {
                startActivity(launch)
                main.post { setPanelOpen(false) }
                "Opening ${match.loadLabel(pm)}."
            } catch (e: Exception) {
                "Android blocked me from opening ${match.loadLabel(pm)}."
            }
        }

        @JavascriptInterface
        fun dial(number: String): String = try {
            startActivity(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            main.post { setPanelOpen(false) }
            "Dialer opened for $number."
        } catch (e: Exception) {
            "I couldn't open the dialer."
        }

        @JavascriptInterface
        fun setAlarm(hour: Int, minute: Int): String = try {
            startActivity(
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Alarm set for %d:%02d.".format(hour, minute)
        } catch (e: Exception) {
            "I couldn't set an alarm on this phone."
        }
    }

    override fun onDestroy() {
        bubble?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        runCatching { speech?.shutdown() }
        runCatching { voskModel?.close() }
        runCatching { llm?.close() }
        web?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
